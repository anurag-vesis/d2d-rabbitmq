package com.vesis.d2d.d2d_rabbitmq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class D2dRabbitmqApplicationTests {

	@Test
	void contextLoads() {
	}

}
