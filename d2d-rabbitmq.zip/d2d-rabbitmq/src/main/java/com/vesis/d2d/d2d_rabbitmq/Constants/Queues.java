package com.vesis.d2d.d2d_rabbitmq.Constants;

public class Queues {
    public static final String USER_FOLLOW_QUEUE = "activity.follow.queue";
    public static final String USER_TRUST_QUEUE = "activity.trust.queue";
    public static final String USER_CRUSH_QUEUE = "activity.crush.queue";
}
