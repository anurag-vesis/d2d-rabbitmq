package com.vesis.d2d.d2d_rabbitmq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class D2dRabbitmqApplication {

	public static void main(String[] args) {
		SpringApplication.run(D2dRabbitmqApplication.class, args);
	}

}
