package com.vesis.d2d.d2d_rabbitmq.configuration;

import com.vesis.d2d.d2d_rabbitmq.Constants.Queues;
import jakarta.annotation.PostConstruct;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class QueueConfig {
    @Bean
    public Queue userTrustQueue() {
        return new Queue(Queues.USER_TRUST_QUEUE, true);
    }
    @Bean
    public Queue userFollowQueue(){
        return new Queue(Queues.USER_FOLLOW_QUEUE, true);
    }

    @Bean
    public Queue userCrushQueue() {
        return new Queue(Queues.USER_CRUSH_QUEUE, true);
    }

//    @Bean
//    public TopicExchange userActivityExchange() {
//        return new TopicExchange("user.activity.exchange", true, false);
//    }

//    @Bean
//    public Binding BindingFollowQueue(){
//        Binding bd =  BindingBuilder.
//                bind(userFollowQueue())
//                .to(userActivityExchange())
//                .with("user.follow");
//        System.out.println("Binding for User Follow Queue created!");
//        return bd;
//    }

//    @Bean
//    public ConnectionFactory connectionFactory() {
//        return new CachingConnectionFactory("localhost");
//    }

//    @Bean
//    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
//        return new RabbitTemplate(connectionFactory);
//    }


//    @PostConstruct
//    public void testConnection() {
//        System.out.println("RabbitMQ Connection Successful!");
//    }

//    @PostConstruct
//    public void publishTestMessage() {
//        ConnectionFactory connectionFactory = new CachingConnectionFactory("localhost");
//        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory());
//        rabbitTemplate.convertAndSend("user.activity.exchange", "user.follow", "Test Message");
//        System.out.println("Test message sent to RabbitMQ!");
//    }


}