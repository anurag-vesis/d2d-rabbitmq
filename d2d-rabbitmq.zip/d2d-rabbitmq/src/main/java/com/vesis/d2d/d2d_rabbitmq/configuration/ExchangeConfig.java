package com.vesis.d2d.d2d_rabbitmq.configuration;

import com.vesis.d2d.d2d_rabbitmq.Constants.Exchanges;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ExchangeConfig {
    @Bean
    public TopicExchange userActivityExchange() {
        return new TopicExchange(Exchanges.USER_ACTIVITY_EXCHANGE, true, false);
    }
}
