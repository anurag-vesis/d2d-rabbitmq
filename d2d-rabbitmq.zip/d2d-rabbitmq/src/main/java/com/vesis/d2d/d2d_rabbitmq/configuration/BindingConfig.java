package com.vesis.d2d.d2d_rabbitmq.configuration;

import com.vesis.d2d.d2d_rabbitmq.Constants.RoutingKeys;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BindingConfig {

    private final QueueConfig queueConfig;
    private final ExchangeConfig exchangeConfig;

    public BindingConfig(QueueConfig queueConfig, ExchangeConfig exchangeConfig) {
        this.queueConfig = queueConfig;
        this.exchangeConfig = exchangeConfig;
    }

    @Bean
    public Binding BindingFollowQueue(){
        return BindingBuilder.
                bind(queueConfig.userFollowQueue())
                .to(exchangeConfig.userActivityExchange())
                .with(RoutingKeys.USER_FOLLOW_ROUTING_KEY);
    }

    @Bean
    public Binding BindingTrustQueue(){
        return BindingBuilder.
                bind(queueConfig.userTrustQueue())
                .to(exchangeConfig.userActivityExchange())
                .with(RoutingKeys.USER_TRUST_ROUTING_KEY);
    }
}
