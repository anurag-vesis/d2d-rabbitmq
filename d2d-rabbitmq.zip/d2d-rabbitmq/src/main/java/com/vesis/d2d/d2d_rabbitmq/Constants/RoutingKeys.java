package com.vesis.d2d.d2d_rabbitmq.Constants;

public class RoutingKeys {
    public static final String USER_FOLLOW_ROUTING_KEY = "user.follow";
    public static final String USER_TRUST_ROUTING_KEY = "user.trust";
}
