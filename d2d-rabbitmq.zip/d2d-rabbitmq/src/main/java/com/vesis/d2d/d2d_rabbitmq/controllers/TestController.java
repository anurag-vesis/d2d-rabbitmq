package com.vesis.d2d.d2d_rabbitmq.controllers;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/rabbitmq")
public class TestController {
    private final RabbitTemplate rabbitTemplate;

    public TestController(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    @RequestMapping("/hello")
    @PostMapping
    public String hello() {
        rabbitTemplate.convertAndSend("user.activity.exchange", "user.follow", "Hello from RabbitMQ Test Controller!");
        return "Hello from RabbitMQ Test Controller!";
    }
}
