package com.vesis.d2d.d2d_rabbitmq.Constants;

public class Exchanges {
    public static final String USER_ACTIVITY_EXCHANGE = "user.activity.exchange";
}
