package com.vesis.d2d.activities.controller;

import com.vesis.d2d.entities.NoSQL.Activity.Repository.TrustActivityRepository;
import com.vesis.d2d.entities.NoSQL.Activity.TrustActivityEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/trust-activities")
public class TrustActivityController {
    @Autowired
    private final TrustActivityRepository trustActivityRepository;

    public TrustActivityController(TrustActivityRepository trustActivityRepository) {
        this.trustActivityRepository = trustActivityRepository;
    }

    @PostMapping
    public ResponseEntity<TrustActivityEntity> createTrustActivity(@RequestBody TrustActivityEntity trustActivityEntity) {
        TrustActivityEntity savedEntity = trustActivityRepository.save(trustActivityEntity);
        return ResponseEntity.ok(savedEntity);
    }
}
